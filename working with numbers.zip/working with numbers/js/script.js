let randomlow = [...Array(250)].map(() => Math.floor(Math.random()*291 + 10)); //250 getallen tussen 10 en 300
let randomhigh = [...Array(250)].map(() => Math.floor(Math.random()*201 + 500)); // 250 getallen tussen 500 en 700

let randomarr = randomlow.concat(randomhigh); // combineren van de 2 eerder gegenereerde arrays

max = 0
for(let i = 0;i<randomarr.length;i++){

    if(randomarr[i] > max) {
        max = randomarr[i];
    }
}
let maxindex = randomarr.indexOf(max);

let paragraph = document.createElement("p");
let text = document.createTextNode(`Uit het array van ${randomarr.length} getallen is het getal ${max} het grootst. Dit getal zit in index ${maxindex} in het array.`);

paragraph.appendChild(text);

let element = document.getElementById("div1");
element.appendChild(paragraph);